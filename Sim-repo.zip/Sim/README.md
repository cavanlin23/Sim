# APEX — Real Car Racing Sim

A browser racing / drifting / free-roam game built with three.js.

- **Race** and **Practice** on six real circuits (Spa, Shanghai, Nürburgring GP, Bahrain, Yas Marina, Marina Bay)
- **Free drive**: open world with a stunt park at the centre
- **Drift**: flat arena with ramps and trick scoring
- 19 real cars as 3D models, manual gearbox and manual brakes

## Run locally
Serve the folder with any static server (browsers block `fetch` from `file://`):

    python3 -m http.server 8000
    # then open http://localhost:8000

## Host on GitHub Pages
Repo → Settings → Pages → Source: *Deploy from a branch* → `main` / `/ (root)`.

Needs internet for the three.js library (loaded from cdnjs / jsDelivr).

## Credits
Created by Cavan, Derek, and Rihaan. 3D models are third-party assets — check each model's licence before redistributing.
