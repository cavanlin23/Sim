APEX - Real Car Racing Sim (static web game, lite models)
Upload this whole folder (index.html + models/) to any static host:
  - Netlify Drop (app.netlify.com/drop): drag the unzipped folder in
  - GitHub Pages / Cloudflare Pages / itch.io (HTML5 game, upload the zip, set index.html as entry)
Needs internet for the three.js library (loaded from cdnjs/jsdelivr).
